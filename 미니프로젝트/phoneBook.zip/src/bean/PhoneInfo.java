package bean;

//Data 클래스
public class PhoneInfo {
	private String name=null;
	private String phoneNum=null;
	private String birth=null;
	//생성자, 메소드 정의할것...
	public PhoneInfo(String name, String phoneNum, String birth) {
		this.name=name;
		this.phoneNum=phoneNum;
		this.birth=birth;
	}
	public PhoneInfo(String name, String phoneNum) {
		this.name=name;
		this.phoneNum=phoneNum;
	}
	public void showPhoneInfo() {
		System.out.println("name: "+name);
		System.out.println("phoneNum: "+phoneNum);
		if(birth!=null) {
			System.out.println("birth: "+birth);
		}
		System.out.println("------------------");
	}
}


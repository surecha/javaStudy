package bean;
//대학 친구 그룹
public class PhoneUnivInfo extends PhoneInfo {
	private String major; //전공
	private int year; //학년
	public PhoneUnivInfo(String name, String phoneNum, String major, int year) {
		super(name, phoneNum);
		this.major=major;
		this.year=year;
	}
	@Override
	public void showPhoneInfo() {
		super.showPhoneInfo();
		System.out.println("major: "+major);
		System.out.println("year: "+year);
	}

}

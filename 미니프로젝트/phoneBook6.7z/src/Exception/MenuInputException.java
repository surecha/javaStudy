package exception;

public class MenuInputException extends Exception {
	private int wrongMenu;
	public MenuInputException(int num) {
		super("잘못된 메뉴 번호입니다.");
		this.wrongMenu=num;
	}
	public void showWrongMenu() {
		System.out.println(wrongMenu+"에 해당하는 번호는 존재하지 않습니다.");
	}
}

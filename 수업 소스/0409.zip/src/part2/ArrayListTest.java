package part2;

public class ArrayListTest {
	public static void main(String[] args) {
		MemberArrayList mList=new MemberArrayList();
		Member memberLee=new Member(1001, "이순신");
		Member memberKim=new Member(1002, "김유신");
		Member memberKang=new Member(1003, "강감찬");
		Member memberHong=new Member(1004, "홍길동");
		
		mList.addMember(memberLee);
		mList.addMember(memberKim);
		mList.addMember(memberKang);
		mList.addMember(memberHong);
		
		mList.showAllMember(); //모든 회원 인적사항 출력 
		if(mList.removeMember(memberKim.getMemberId()))  //1002 삭제
			System.out.println("삭제 성공");
		else
			System.out.println("삭제 실패");
		mList.showAllMember(); //나머지 회원 인적사항 출력
	}
}

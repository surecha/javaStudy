package common;

public interface GroupMenu {
	int NORMAL=1, UNIV=2, COMPANY=3;
	//추상 메소드
}

package controller;

import bean.PhoneInfo;

//PhoneInfo 배열을 제어하는 클래스
public class PhoneBookManager {

	public static final int MAX=100;
	private PhoneInfo[] phoneList=new PhoneInfo[MAX];
	private int cnt=0;  //배열 인덱스, 인원수
	public void inputData() {
		System.out.println("데이터 입력 시작...");
		System.out.print("이름: ");
		String name=PhoneBook.sc.next(); 
		System.out.print("전화번호: ");
		String phoneNum=PhoneBook.sc.next(); 
		System.out.print("생일: ");
		String birth=PhoneBook.sc.next(); 
		phoneList[cnt]=new PhoneInfo(name, phoneNum,birth);
		cnt++;
		System.out.println("데이터 입력이 완료됨!");
	}
	public void showAllData() {
		System.out.println("데이터 전체 리스트 출력...");
		for(int i=0;i<cnt;i++) {
			phoneList[i].showPhoneInfo();
		}
	}
	public void searchData() {
		System.out.println("데이터 검색을 시작....");
		System.out.print("검색 이름: ");
		String name=PhoneBook.sc.next();
		for(int i=0;i<cnt;i++) {
			if(name.equals(phoneList[i].getName())) {
				phoneList[i].showPhoneInfo();
				System.out.println("검색이 완료됨!");
				return; //동명이인이 없으면
			}
		}
		System.out.println("검색할 데이터가 존재하지 않음!");
	}
	public void deleteData() {
		System.out.println("데이터 삭제를 시작....");
		System.out.print("삭제 이름: ");
		String name=PhoneBook.sc.next();
		for(int i=0;i<cnt;i++) {
			if(name.equals(phoneList[i].getName())) {
				phoneList[i]=phoneList[cnt-1];
//				for(int j=i;j<(cnt-1);j++) {
//					phoneList[j]=phoneList[j+1];
//				}
				cnt--;
				System.out.println("삭제 완료됨!");
				return; //동명이인이 없으면
			}
		}
		System.out.println("삭제할 데이터가 존재하지 않음!");
	}
}

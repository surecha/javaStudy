package part2;

import java.util.ArrayList;
import java.util.Iterator;

public class MemberArrayList {
	private ArrayList<Member> mList; //=new ArrayList<>();
	
	public MemberArrayList() {
		this.mList=new ArrayList<>();
	}
	public MemberArrayList(int size) {
		this.mList=new ArrayList<>(size);
	}
	public void addMember(Member member) {
		mList.add(member);
		//cnt++;
	}
	public void showAllMember() {
		System.out.println("mList: "+mList);  //ArrayList의 toString()
		for(Member member: mList) {
			System.out.println(member);  //member.toString()
			//member.showInfo();
		}
		System.out.println("----------------");
	}
	public boolean removeMember(int memberId) { //1002
		Iterator<Member> ir = mList.iterator();
		while(ir.hasNext()) {
			Member member=ir.next();
			int curId=member.getMemberId();
			if(curId==memberId) {
				ir.remove(); //반복자 현재 요소 삭제
				//mList.remove(member); //ArrayList에서 참조값으로 삭제
				return true;
			}
		}
		System.out.println(memberId+"가 존재하지 않아요");
		return false; //실패
//		for(int i=0;i<mList.size();i++) {
//			Member member=mList.get(i);
//			int curId=member.getMemberId(); //
//			if(curId == memberId) {
//				mList.remove(i);
//				return true;  //성공
//			}
//		}
//		System.out.println(memberId+"가 존재하지 않아요");
//		return false; //실패
	}

}

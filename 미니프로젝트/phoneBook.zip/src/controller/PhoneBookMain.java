package controller;

import bean.PhoneInfo;

//제어 클래스
public class PhoneBookMain {
	public static void main(String[] args) {
		PhoneInfo pInfo1=new PhoneInfo("홍길동", "111-2222", "90/08/30");
		PhoneInfo pInfo2=new PhoneInfo("이순신", "222-3333");
		
		pInfo1.showPhoneInfo();  //name:홍길동,  phoneNum: 111-2222, birth: 90/08/30
		pInfo2.showPhoneInfo();  //name:이순신,  phoneNum: 222-3333

	}

}

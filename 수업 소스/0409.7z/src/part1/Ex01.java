package part1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


public class Ex01 {
    //자료구조 & 알고리즘
	public static void main(String[] args) {
		List<String> list=Arrays.asList("aaa","bbb","ccc");
		//ArrayList<String> list=new ArrayList<>();
		//list.add("first");
		//list.add("second"); 
		//list.add("third");
		//list.add("third");
		for(String e: list) {
			System.out.println(e);
		}
		
		
		//반복자(Iterator,리모콘): set,list계열 상관없이 사용
		//반복자를 size(), get(), remove() 메소드로 바꾸기
		
		System.out.println(list.size());
		
		for(String e:list) {
			System.out.println(e);
		}
		System.out.println("---------------");
		for(int i=0;i<list.size();i++) {
			//System.out.println(list.get(i));
			if(list.get(i).equals("third")) {
				list.remove(i);  //삭제후 자동 size감소 
				i--;
			}
		}
		System.out.println("---------------");
		for(String e:list) {
			System.out.println(e);
		}
//		Iterator<String> itr = list.iterator();
//		while(itr.hasNext()) {
//			String str=itr.next();
//			System.out.println(str);
//			if(str.equals("third")) {
//				itr.remove();  //현재 반복자가 참조하는 것 삭제 
//			}
//		}
//		System.out.println("----------------");
//		itr=list.iterator();
//		while(itr.hasNext()) {
//			String str=itr.next();
//			System.out.println(str);
//		}
		System.out.println("------------------");
		System.out.println(list.size());
		//for-each문
		//for(String e: list) {
		//	System.out.println(e);
		//}
	}

}

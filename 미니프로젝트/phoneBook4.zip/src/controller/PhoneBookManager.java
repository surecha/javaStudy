package controller;

import bean.PhoneCompanyInfo;
import bean.PhoneInfo;
import bean.PhoneUnivInfo;

//PhoneInfo 배열을 제어하는 클래스
public class PhoneBookManager {
	public static final int MAX=100;
	private PhoneInfo[] phoneList=new PhoneInfo[MAX];
	private int cnt=0;  //배열 인덱스, 인원수

	public void inputData() {
		System.out.println("데이터 입력 시작...");
		System.out.println("1.일반, 2.대학, 3.회사");
		System.out.print("그룹선택: ");
		int groupNum=PhoneBook.sc.nextInt();
		PhoneInfo info=null;
		switch(groupNum) {
		case 1:
			info=normalInputData();
			break;
		case 2:
			info=univInputData();
			break;
		case 3:
			info=companyInputData();
			break;
		}
		phoneList[cnt++]=info;
		System.out.println("데이터 입력이 완료됨!");
	}
	private PhoneInfo normalInputData() {
		System.out.print("이름: ");
		String name=PhoneBook.sc.next(); 
		System.out.print("전화번호: ");
		String phoneNum=PhoneBook.sc.next(); 
		return new PhoneInfo(name, phoneNum);
	}
	private PhoneInfo univInputData() {
		System.out.print("이름: ");
		String name=PhoneBook.sc.next(); 
		System.out.print("전화번호: ");
		String phoneNum=PhoneBook.sc.next();
		System.out.print("전공: ");
		String major=PhoneBook.sc.next(); 
		System.out.print("학년: ");
		int year=PhoneBook.sc.nextInt();
		return new PhoneUnivInfo(name, phoneNum,major,year);
	}
	private PhoneCompanyInfo companyInputData() {
		System.out.print("이름: ");
		String name=PhoneBook.sc.next(); 
		System.out.print("전화번호: ");
		String phoneNum=PhoneBook.sc.next();
		System.out.print("회사: ");
		String company=PhoneBook.sc.next(); 
		return new PhoneCompanyInfo(name, phoneNum,company);
	}
	public void showAllData() {
		System.out.println("데이터 전체 리스트 출력...");
		for(int i=0;i<cnt;i++) {
			phoneList[i].showPhoneInfo();
			System.out.println("---------------");
		}
	}
	public void searchData() {
		System.out.println("데이터 검색을 시작....");
		System.out.print("검색 이름: ");
		String name=PhoneBook.sc.next();
		
		int idx=searchIdx(name); //에러시 -1리턴
		if(idx<0) {
			System.out.println("해당 데이터가 존재하지 않아요!!");
		}else {
			phoneList[idx].showPhoneInfo();
			System.out.println("검색이 완료됨!");
		}
	}
	public void deleteData() {
		System.out.println("데이터 삭제를 시작....");
		System.out.print("삭제 이름: ");
		String name=PhoneBook.sc.next();
		int idx=searchIdx(name); //에러시 -1리턴
		if(idx<0) {
			System.out.println("해당 데이터가 존재하지 않아요!!");
		}else {
			phoneList[idx]=phoneList[cnt-1];
			cnt--;
			System.out.println("삭제 완료됨!");
		}
	}//end deleteData
	private int searchIdx(String name) {
		for(int i=0;i<cnt;i++) {
			if(name.equals(phoneList[i].getName())) {
				return i;
			}
		}
		return -1;
	}
}//end class

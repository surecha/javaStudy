package part1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

class Animal{ }
class Dog extends Animal{ }
class Cat extends Animal{ }

public class Ex02 {
	public static void main(String[] args) {
		List<Cat> list1=new ArrayList<Cat>();
		list1.add(new Cat());
		List<Dog> list2=new ArrayList<Dog>();
		list2.add(new Dog());
		list2.add(new Dog());
		print(list1);
		print(list2);
	}
	private static void print(List<? extends Animal> list) {
		System.out.println(list);
	}
}

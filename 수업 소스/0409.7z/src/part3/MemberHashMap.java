package part3;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class MemberHashMap {
	private HashMap<Integer, Member> hashMap;

	public MemberHashMap() {
		hashMap = new HashMap<Integer, Member>();
	}

	public void addMember(Member member) {
		hashMap.put(member.getMemberId(), member);
	}

	public boolean removeMember(int memberId) {
		// 반환형이 참조형일때 실패시 null값 반환
		Member member = hashMap.remove(memberId);
		if (member != null)
			return true;
		System.out.println("no element");
		return false;
// 		if(hashMap.containsKey(memberId)) { //if문 생략가능
//			hashMap.remove(memberId);
//			return true;
//		}
//		System.out.println("no element");
//		return false;		
	}

	public void showAllMember() {
		// HashMap에서 iterator 사용법1
//		Collection<Member> mList = hashMap.values();
//		System.out.println("Collection:"+mList);
//		for(Member mb: mList) {
//			System.out.println(mb);
//		}
//		System.out.println("==================");
		// HashMap에서 iterator 사용법2
		Set<Integer> keySet = hashMap.keySet(); // {1001,1002,1003}
		Iterator<Integer> ir = keySet.iterator();
		while (ir.hasNext()) {
			int key = ir.next();
			Member member = hashMap.get(key);
			System.out.println(member); // toString()
		}
	}
}

package bean;

import java.util.Comparator;

//Data 클래스
public class PhoneInfo { //implements Comparable<PhoneInfo>{
	private String name;
	private String phoneNum;
	
	public PhoneInfo(String name, String phoneNum) {
		this.name=name;
		this.phoneNum=phoneNum;
	}
	@Override
	public int hashCode() {
		return name.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		PhoneInfo cmp=(PhoneInfo)obj;
		if(name.equals(cmp.getName())) {
			return true;
		}
		return false;
	}
	//자식 클래스에서 재정의 
	public void showPhoneInfo() {
		System.out.println("name: "+name);
		System.out.println("phoneNum: "+phoneNum);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
//	@Override
//	public int compare(String s1, String s2) {
//		return s1.compareTo(s2);
//	}
//	@Override  //정렬기준, 동등비교
//	public int compareTo(PhoneInfo obj) {
//		if(name.compareTo(obj.getName())>0)
//			return 1;
//		else if(name.compareTo(obj.getName())<0)
//			return -1;
//		else { //if(name.compareTo(obj.getName())==0)
//			//이름이 일치시 전화번호 정렬
//			return phoneNum.compareTo(obj.getPhoneNum());
//		}
//	}
}


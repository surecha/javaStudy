package part1;

public class Person {
	private String name;
	private int age;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Person() {
		System.out.println("Person 디폴트 생성자");
	}
	public Person(String name, int age) {
		this.name=name;
		this.age=age;
	}
	public void showInfo() {
		System.out.println("name: "+name);
		System.out.println("age: "+age);
	}
	public void sleep() {
		System.out.println("사람은 8시간 잔다.");
	}
	public void eat() {
		System.out.println("사람은 세끼를 먹는다.");
	}
}

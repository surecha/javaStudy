package common;

public interface MainMenu {
	int INPUT=1, SEARCH=2,DELETE=3,SHOWALL=4,EXIT=5;
	//추상 메소드
}

package controller;

import java.util.Scanner;

import bean.PhoneInfo;
    
//제어 클래스
public class PhoneBook {
	public static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		PhoneBookManager manager=new PhoneBookManager();
		
		while(true) {
			showMenu();
			int menuNum=sc.nextInt();
			switch(menuNum) {
			case 1:
				manager.inputData();
				break;
			case 2:
				manager.searchData();
				break;
			case 3:
				manager.deleteData();  //나중에 설명
				break;
			case 4:
				manager.showAllData();
				break;
			case 5:
				System.out.println("전화번호부가 종료되었다.");
				return;
			}
		}
	}
	
	private static void showMenu() {
		System.out.println("메뉴를 선택하세요.");
		System.out.println("------------------");
		System.out.println("1.데이터 입력");
		System.out.println("2.데이터 검색");
		System.out.println("3.데이터 삭제");
		System.out.println("4.데이터 전체출력");
		System.out.println("5.프로그램 종료");
		System.out.println("------------------");
		System.out.print("선택: ");
	}

}

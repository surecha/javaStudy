package part1;

public class Student extends Person{
	//name, age, eat(), sleep() //재활용
	private int sNo;
	
	public Student(String name, int age, int sNo) {
		super(name, age);  //Person(name, age);
		//상속<정보은닉
		//this.name=name;
		//this.age=age;
		this.sNo=sNo;
	}
	public void study() {
		System.out.println("학생은 공부를 한다.");
	}
	public void exam() {
		System.out.println("학생은 시험을 본다.");
	}
	@Override
	public void sleep() {
		super.sleep();  //8시간
		System.out.println("학생은 TV 유튜브 줄인다.");
	}
	@Override  //재정의
	public void showInfo() {
		super.showInfo(); //이름, 나이
		System.out.println("sNo: "+sNo);
	}
	
	
}

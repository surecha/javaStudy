package bean;

//Data 클래스
public class PhoneInfo {
	private String name;
	private String phoneNum;
	
	public PhoneInfo(String name, String phoneNum) {
		this.name=name;
		this.phoneNum=phoneNum;
	}
	//자식 클래스에서 재정의 
	public void showPhoneInfo() {
		System.out.println("name: "+name);
		System.out.println("phoneNum: "+phoneNum);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
}


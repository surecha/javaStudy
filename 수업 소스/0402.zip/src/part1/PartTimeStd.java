package part1;

public class PartTimeStd extends Student {
	//name, age, eat(), sleep()
	//sNo, study(), exam();
	private int time;
	private int pay;
	//생성자
	public PartTimeStd(String name, int age, int sNo, int time,int pay) {
		super(name, age, sNo);  //Student
		this.time=time;
		this.pay=pay;
	}
	//showInfo() 오버라이딩(재정의)
	
	public void work() {
		System.out.println("파트학생은 일도 한다.");
	}
	public int getPay() {
		return time*pay;
	}
	@Override
	public void sleep() {
		//super.sleep();
		System.out.println("파트타임학생은 6시간 잔다.");
	}
	@Override  //재정의
	public void showInfo() {
		super.showInfo();  //Student.showInfo() //name,age,sNo
		System.out.println("주급여: "+getPay());
	}
}

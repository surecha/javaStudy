package controller;

import java.util.InputMismatchException;
import java.util.Scanner;

import bean.PhoneInfo;
import common.MainMenu;
import exception.MenuInputException;

//제어 클래스
public class PhoneBook {
	public static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		PhoneBookManager manager = new PhoneBookManager();

		while (true) {
			try {
				showMenu();
				int menuNum = sc.nextInt();
				if (menuNum < MainMenu.INPUT || menuNum > MainMenu.EXIT) {
					//객관적예외:10/0  //JVM: throw new Ari...Exception()
					//주관적 예외
					throw new MenuInputException(menuNum);
				}
				switch (menuNum) {
				case MainMenu.INPUT:
					manager.inputData();
					break;
				case MainMenu.SEARCH:
					manager.searchData();
					break;
				case MainMenu.DELETE:
					manager.deleteData(); // 나중에 설명
					break;
				case MainMenu.SHOWALL:
					manager.showAllData();
					break;
				case MainMenu.EXIT:
					System.out.println("전화번호부가 종료되었다.");
					return;
				}
			} catch (MenuInputException ex) {
				System.out.println(ex.getMessage());
				ex.showWrongMenu();
				System.out.println("메뉴선택을 처음부터 다시 진행하겠습니다.");
			} catch (InputMismatchException ex) {
				System.out.println("메뉴선택은 정수만 가능합니다.");
				sc.nextLine();
			}
		}//while end
	}//main end

	private static void showMenu() {
		System.out.println("메뉴를 선택하세요.");
		System.out.println("------------------");
		System.out.println("1.데이터 입력");
		System.out.println("2.데이터 검색");
		System.out.println("3.데이터 삭제");
		System.out.println("4.데이터 전체출력");
		System.out.println("5.프로그램 종료");
		System.out.println("------------------");
		System.out.print("선택: ");
	}

}

package part3;

import java.util.HashMap;
import java.util.Map;

import part3.Member;

public class HashMapTest {
	public static void main(String[] args) {
		MemberHashMap mHashMap=new MemberHashMap();
		Member memberLee=new Member(1001, "이순신");
		Member memberKim=new Member(1002, "김유신");
		Member memberKang=new Member(1003, "강감찬");
		Member memberHong=new Member(1004, "홍길동");
		
		mHashMap.addMember(memberLee);
		mHashMap.addMember(memberKim);
		mHashMap.addMember(memberKang);
		mHashMap.addMember(memberHong);
		mHashMap.removeMember(memberKang.getMemberId()+10);
		mHashMap.showAllMember(); //모든 회원 인적사항 출력 
//		Map<Integer, String> hashMap=new HashMap<>();
//		hashMap.put(1005, "kim");
//		hashMap.put(1002, "lee");
//		hashMap.put(1003, "park");
//		hashMap.put(1004, "hong");
//		System.out.println(hashMap); 
	}
}

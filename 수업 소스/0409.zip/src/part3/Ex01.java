package part3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Ex01 {
	public static void main(String[] args) {
		HashMap<String, Object> hMap=new HashMap<>();
		List<Map<String,String>> mList=new ArrayList<>();
		//List<Member> mList2=new ArrayList<>();
		hMap.put("id", "cha");
		hMap.put("pw", "1234");
		hMap.put("name", "cha");
		hMap.put("age", 10);
		System.out.println((Integer)hMap.get("age")-1);
		//System.out.println(Integer.parseInt(hMap.get("age"))-1);
		
		//mList.add(hMap);
		hMap=new HashMap<>();
		hMap.put("id", "kim");
		hMap.put("pw", "1234");
		hMap.put("name", "kim");
		hMap.put("age", "20");
		//mList.add(hMap);
		
		System.out.println(mList);
		System.out.println(mList.size());
		
	}
}

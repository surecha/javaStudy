package part1;
public class Ex01 {
	public static void main(String[] args) {
		PartTimeStd pts=new PartTimeStd("kim",10, 1, 30,10000);
		Student std=new Student("kim",10, 1);
		Person person=new Person("kim",10);
		printMethod(pts);
		System.out.println("---------");
		printMethod(std);
		System.out.println("---------");
		printMethod(person);
	}
	//
	private static void printMethod(Person person) {
		person.showInfo();  //다형성
		person.sleep();
	}
	
}

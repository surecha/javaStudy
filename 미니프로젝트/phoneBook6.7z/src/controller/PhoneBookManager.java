package controller;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

import bean.PhoneCompanyInfo;
import bean.PhoneInfo;
import bean.PhoneUnivInfo;
import common.GroupMenu;
import exception.MenuInputException;

//String 클래스 처럼 이미 Comparable이 구현된 경우 Comparator로 비교방식을 다시 구현가능 
//class MyCompare implements Comparator<String>{
//	@Override
//	public int compare(String s1, String s2) {
//		return s1.compareTo(s2); // * (-1);  //역순출력
//	}
//}
//PhoneInfo 배열을 제어하는 클래스
public class PhoneBookManager {
//	public static final int MAX=100;
//	private PhoneInfo[] phoneList=new PhoneInfo[MAX];
//	private int cnt=0;  //배열 인덱스, 인원수
	HashSet<PhoneInfo> infoSet=new HashSet<PhoneInfo>();
	static PhoneBookManager inst=null;
	private PhoneBookManager() {  } //클래스 외부에서 객체 생성 금지
	public static PhoneBookManager creatManagerInst(){	
	   	if(inst==null)
			inst=new PhoneBookManager();
		return inst;
	}
	public void inputData() throws MenuInputException {
		System.out.println("데이터 입력 시작...");
		System.out.println("1.일반, 2.대학, 3.회사");
		System.out.print("그룹선택: ");
		
		int groupNum=PhoneBook.sc.nextInt();
		if(groupNum<GroupMenu.NORMAL || groupNum>GroupMenu.COMPANY) {
			throw new MenuInputException(groupNum);
		}
		PhoneInfo info=null;
		switch(groupNum) {
		case GroupMenu.NORMAL:
			info=normalInputData();
			break;
		case GroupMenu.UNIV:
			info=univInputData();
			break;
		case GroupMenu.COMPANY:
			info=companyInputData();
			break;
		}
		//phoneList[cnt++]=info;
		boolean isAdded=infoSet.add(info);
		if(isAdded) {
			System.out.println("데이터 입력이 완료됨!");
		}else {
			System.out.println("이미 저장된 데이터입니다!");
		}
	}	
	private PhoneInfo normalInputData() {
		System.out.print("이름: ");
		String name=PhoneBook.sc.next(); 
		System.out.print("전화번호: ");
		String phoneNum=PhoneBook.sc.next(); 
		return new PhoneInfo(name, phoneNum);
	}
	private PhoneInfo univInputData() {
		System.out.print("이름: ");
		String name=PhoneBook.sc.next(); 
		System.out.print("전화번호: ");
		String phoneNum=PhoneBook.sc.next();
		System.out.print("전공: ");
		String major=PhoneBook.sc.next(); 
		System.out.print("학년: ");
		int year=PhoneBook.sc.nextInt();
		return new PhoneUnivInfo(name, phoneNum,major,year);
	}
	private PhoneCompanyInfo companyInputData() {
		System.out.print("이름: ");
		String name=PhoneBook.sc.next(); 
		System.out.print("전화번호: ");
		String phoneNum=PhoneBook.sc.next();
		System.out.print("회사: ");
		String company=PhoneBook.sc.next(); 
		return new PhoneCompanyInfo(name, phoneNum,company);
	}
	public void showAllData() {
		System.out.println("데이터 전체 리스트 출력...");
		for(PhoneInfo info:infoSet) {
			info.showPhoneInfo();
			System.out.println("---------------");
		}
	}
	public void searchData() {
		System.out.println("데이터 검색을 시작....");
		System.out.print("검색 이름: ");
		String name=PhoneBook.sc.next();
		
		PhoneInfo info=search(name);
		if(info==null) {
			System.out.println("해당 데이터가 존재하지 않음!!");
		}else {
			//System.out.println(info);  //toString()
			info.showPhoneInfo();
			System.out.println("검색이 완료됨!");
		}
//		int idx=searchIdx(name); //에러시 -1리턴
//		if(idx<0) {
//			System.out.println("해당 데이터가 존재하지 않아요!!");
//		}else {
//			phoneList[idx].showPhoneInfo();
//			System.out.println("검색이 완료됨!");
//		}
	}
	public void deleteData() {
		System.out.println("데이터 삭제를 시작....");
		System.out.print("삭제 이름: ");
		String name=PhoneBook.sc.next();
		//int idx=searchIdx(name); //에러시 -1리턴
		Iterator<PhoneInfo> itr=infoSet.iterator();
		
		PhoneInfo info=search(name);
		if(info==null) {
			System.out.println("해당 데이터가 존재하지 않음!!");
		}else {
			infoSet.remove(info);
			System.out.println("삭제 완료됨!");
		}
		//search메소드 호출없이 직접 삭제 처리할때
//		while(itr.hasNext()) {
//			PhoneInfo curInfo=itr.next();
//			if(name.equals(curInfo.getName())) {
//				itr.remove();
//				//infoSet.remove(curInfo);
//				System.out.println("삭제 완료됨!");
//				return;
//			}
//		}
//		if(idx<0) {
//			System.out.println("해당 데이터가 존재하지 않아요!!");
//		}else {
//			phoneList[idx]=phoneList[cnt-1];
//			cnt--;
//			System.out.println("삭제 완료됨!");
//		}
	}//end deleteData
	
	private PhoneInfo search(String name) {
		Iterator<PhoneInfo> itr=infoSet.iterator();
		while(itr.hasNext()) {
			PhoneInfo curInfo=itr.next();
			if(name.equals(curInfo.getName())) {
				return curInfo;
			}
		}
		return null; //검색 실패
	}
//	private int searchIdx(String name) {
//		for(int i=0;i<cnt;i++) {
//			if(name.equals(phoneList[i].getName())) {
//				return i;
//			}
//		}
//		return -1;
//	}
}//end class
